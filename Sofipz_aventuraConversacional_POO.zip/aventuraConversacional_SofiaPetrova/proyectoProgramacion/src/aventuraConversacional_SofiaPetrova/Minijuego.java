package aventuraConversacional_SofiaPetrova;

public interface Minijuego {
    public void iniciar();
}
